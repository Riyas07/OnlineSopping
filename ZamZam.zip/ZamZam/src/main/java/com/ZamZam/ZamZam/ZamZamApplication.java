package com.ZamZam.ZamZam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZamZamApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZamZamApplication.class, args);
	}

}
 